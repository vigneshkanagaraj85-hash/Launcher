package com.simple.launcher

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.PagerSnapHelper
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

data class AppInfo(
    val label: String,
    val pkg: String,
    val activity: String,
    val icon: Bitmap
)

class MainActivity : Activity() {

    companion object {
        const val COLS = 4
        const val ROWS = 6
        const val DOCK_MAX = 4
    }

    private lateinit var pager: RecyclerView
    private lateinit var dots: LinearLayout
    private lateinit var dock: LinearLayout
    private lateinit var searchOverlay: View
    private lateinit var searchInput: EditText
    private lateinit var searchGrid: GridView
    private lateinit var searchAdapter: AppAdapter

    private val pageAdapter = PageAdapter()
    private val snap = PagerSnapHelper()
    private val prefs by lazy { getSharedPreferences("launcher", MODE_PRIVATE) }
    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    private var allApps: List<AppInfo> = emptyList()
    private var pageCount = 0
    private var currentPage = 0

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) = loadApps()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        pager = findViewById(R.id.pager)
        dots = findViewById(R.id.dots)
        dock = findViewById(R.id.dock)
        searchOverlay = findViewById(R.id.searchOverlay)
        searchInput = findViewById(R.id.searchInput)
        searchGrid = findViewById(R.id.searchGrid)

        // Home pages: இடது/வலது swipe
        pager.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        pager.adapter = pageAdapter
        snap.attachToRecyclerView(pager)
        pager.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(rv: RecyclerView, newState: Int) {
                if (newState == RecyclerView.SCROLL_STATE_IDLE) {
                    val v = snap.findSnapView(rv.layoutManager) ?: return
                    currentPage = rv.getChildAdapterPosition(v).coerceAtLeast(0)
                    updateDots()
                }
            }
        })

        // Search
        searchAdapter = AppAdapter()
        searchGrid.adapter = searchAdapter
        searchGrid.setOnItemClickListener { _, _, pos, _ -> launch(searchAdapter.getItem(pos)) }
        searchGrid.setOnItemLongClickListener { _, v, pos, _ ->
            showMenu(v, searchAdapter.getItem(pos)); true
        }
        findViewById<View>(R.id.searchPill).setOnClickListener { openSearch() }
        findViewById<View>(R.id.searchCancel).setOnClickListener { closeSearch() }
        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = filterSearch(s?.toString().orEmpty())
        })
        searchInput.setOnEditorActionListener { _, _, _ ->
            if (searchAdapter.count > 0) launch(searchAdapter.getItem(0))
            true
        }

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(packageReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(packageReceiver, filter)
        }

        loadApps()
    }

    // ---------- Apps ----------

    private fun loadApps() {
        executor.execute {
            val pm = packageManager
            val size = (58 * resources.displayMetrics.density).toInt()
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val apps = pm.queryIntentActivities(intent, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map {
                    AppInfo(
                        label = it.loadLabel(pm).toString(),
                        pkg = it.activityInfo.packageName,
                        activity = it.activityInfo.name,
                        icon = toSquircle(it.loadIcon(pm), size)
                    )
                }
                .sortedBy { it.label.lowercase() }

            mainHandler.post {
                allApps = apps
                refreshHome()
            }
        }
    }

    /** எல்லா icon-களையும் iPhone போன்ற rounded-square வடிவில் மாற்றுகிறது */
    private fun toSquircle(d: Drawable, size: Int): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val r = size * 0.225f
        val path = Path().apply {
            addRoundRect(RectF(0f, 0f, size.toFloat(), size.toFloat()), r, r, Path.Direction.CW)
        }
        c.clipPath(path)
        if (Build.VERSION.SDK_INT >= 26 && d is AdaptiveIconDrawable) {
            val pad = size / 4
            d.background?.let { it.setBounds(-pad, -pad, size + pad, size + pad); it.draw(c) }
            d.foreground?.let { it.setBounds(-pad, -pad, size + pad, size + pad); it.draw(c) }
        } else {
            c.drawColor(Color.WHITE)
            val inset = (size * 0.12f).toInt()
            d.setBounds(inset, inset, size - inset, size - inset)
            d.draw(c)
        }
        return bmp
    }

    // ---------- Dock ----------

    private fun dockPackages(): List<String> {
        val saved = prefs.getString("dock", null)
        if (saved != null) return saved.split(",").filter { it.isNotBlank() }
        val defaults = defaultDock()
        saveDock(defaults)
        return defaults
    }

    private fun saveDock(list: List<String>) {
        prefs.edit().putString("dock", list.joinToString(",")).apply()
    }

    /** முதல் முறை: Phone, Messages, Browser, Camera */
    private fun defaultDock(): List<String> {
        val pm = packageManager
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING),
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER),
            Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
        )
        val known = allApps.map { it.pkg }.toSet()
        return intents.mapNotNull {
            pm.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
        }.filter { it in known }.distinct().take(DOCK_MAX)
    }

    private fun buildDock(apps: List<AppInfo>) {
        dock.removeAllViews()
        dock.visibility = if (apps.isEmpty()) View.GONE else View.VISIBLE
        val inflater = LayoutInflater.from(this)
        apps.forEach { app ->
            val cell = inflater.inflate(R.layout.item_app, dock, false)
            cell.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            bindCell(cell, app, showLabel = false)
            dock.addView(cell)
        }
    }

    // ---------- Home ----------

    private fun refreshHome() {
        val dockPkgs = dockPackages()
        val dockApps = dockPkgs.mapNotNull { p -> allApps.firstOrNull { it.pkg == p } }
        val pages = allApps.filter { it.pkg !in dockPkgs }.chunked(COLS * ROWS)
        pageCount = pages.size
        currentPage = currentPage.coerceIn(0, (pageCount - 1).coerceAtLeast(0))
        pageAdapter.submit(pages)
        buildDock(dockApps)
        updateDots()
        filterSearch(searchInput.text.toString())
    }

    private fun updateDots() {
        dots.removeAllViews()
        if (pageCount <= 1) return
        val d = resources.displayMetrics.density
        for (i in 0 until pageCount) {
            val dot = View(this)
            val s = (7 * d).toInt()
            dot.layoutParams = LinearLayout.LayoutParams(s, s).apply {
                marginStart = (4 * d).toInt(); marginEnd = (4 * d).toInt()
            }
            dot.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(if (i == currentPage) Color.WHITE else Color.argb(90, 255, 255, 255))
            }
            dots.addView(dot)
        }
    }

    fun bindCell(cell: View, app: AppInfo, showLabel: Boolean = true) {
        cell.visibility = View.VISIBLE
        cell.findViewById<ImageView>(R.id.icon).setImageBitmap(app.icon)
        val label = cell.findViewById<TextView>(R.id.label)
        label.text = app.label
        label.visibility = if (showLabel) View.VISIBLE else View.GONE
        cell.setOnClickListener { launch(app) }
        cell.setOnLongClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            showMenu(it, app); true
        }
    }

    // ---------- Actions ----------

    private fun launch(app: AppInfo) {
        val intent = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(ComponentName(app.pkg, app.activity))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, R.string.cannot_open, Toast.LENGTH_SHORT).show()
        }
        closeSearch()
    }

    private fun showMenu(anchor: View, app: AppInfo) {
        val uri = Uri.parse("package:${app.pkg}")
        val dockPkgs = dockPackages()
        val inDock = app.pkg in dockPkgs
        PopupMenu(this, anchor).apply {
            if (inDock) menu.add(0, 3, 0, R.string.dock_remove)
            else if (dockPkgs.size < DOCK_MAX) menu.add(0, 3, 0, R.string.dock_add)
            menu.add(0, 1, 1, R.string.app_info)
            menu.add(0, 2, 2, R.string.uninstall)
            setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    1 -> safeStart(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri))
                    2 -> safeStart(Intent(Intent.ACTION_DELETE, uri))
                    3 -> {
                        saveDock(if (inDock) dockPkgs - app.pkg else dockPkgs + app.pkg)
                        refreshHome()
                    }
                }
                true
            }
            show()
        }
    }

    private fun safeStart(i: Intent) {
        try { startActivity(i) } catch (_: Exception) {}
    }

    // ---------- Search ----------

    private fun openSearch() {
        searchOverlay.alpha = 0f
        searchOverlay.visibility = View.VISIBLE
        searchOverlay.animate().alpha(1f).setDuration(180).start()
        filterSearch("")
        searchInput.requestFocus()
        searchInput.post {
            getSystemService(InputMethodManager::class.java)
                ?.showSoftInput(searchInput, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    private fun closeSearch() {
        searchInput.setText("")
        searchInput.clearFocus()
        getSystemService(InputMethodManager::class.java)
            ?.hideSoftInputFromWindow(searchInput.windowToken, 0)
        searchOverlay.visibility = View.GONE
    }

    private fun filterSearch(query: String) {
        val q = query.trim()
        searchAdapter.submit(
            if (q.isEmpty()) allApps else allApps.filter { it.label.contains(q, ignoreCase = true) }
        )
    }

    // ---------- System ----------

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (searchOverlay.visibility == View.VISIBLE) closeSearch()
        else if (pageCount > 0) { pager.smoothScrollToPosition(0) }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (searchOverlay.visibility == View.VISIBLE) closeSearch()
        else if (pageCount > 0) pager.smoothScrollToPosition(0)
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(packageReceiver) } catch (_: Exception) {}
        executor.shutdown()
    }

    // ---------- Adapters ----------

    inner class PageAdapter : RecyclerView.Adapter<PageAdapter.Holder>() {
        private var pages: List<List<AppInfo>> = emptyList()

        inner class Holder(view: View, val cells: List<View>) : RecyclerView.ViewHolder(view)

        fun submit(list: List<List<AppInfo>>) {
            pages = list
            notifyDataSetChanged()
        }

        override fun getItemCount() = pages.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
            val ctx = parent.context
            val inflater = LayoutInflater.from(ctx)
            val page = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
                )
                val p = (8 * resources.displayMetrics.density).toInt()
                setPadding(p, 0, p, 0)
            }
            val cells = mutableListOf<View>()
            repeat(ROWS) {
                val row = LinearLayout(ctx).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = android.view.Gravity.CENTER_VERTICAL
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
                }
                repeat(COLS) {
                    val cell = inflater.inflate(R.layout.item_app, row, false)
                    cell.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    row.addView(cell)
                    cells.add(cell)
                }
                page.addView(row)
            }
            return Holder(page, cells)
        }

        override fun onBindViewHolder(holder: Holder, position: Int) {
            val apps = pages[position]
            holder.cells.forEachIndexed { i, cell ->
                if (i < apps.size) bindCell(cell, apps[i])
                else {
                    cell.visibility = View.INVISIBLE
                    cell.setOnClickListener(null)
                    cell.setOnLongClickListener(null)
                }
            }
        }
    }

    inner class AppAdapter : BaseAdapter() {
        private var items: List<AppInfo> = emptyList()

        fun submit(list: List<AppInfo>) {
            items = list
            notifyDataSetChanged()
        }

        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val view = convertView
                ?: LayoutInflater.from(this@MainActivity).inflate(R.layout.item_app, parent, false)
            val app = items[position]
            view.findViewById<ImageView>(R.id.icon).setImageBitmap(app.icon)
            view.findViewById<TextView>(R.id.label).apply {
                text = app.label
                visibility = View.VISIBLE
            }
            return view
        }
    }
}
